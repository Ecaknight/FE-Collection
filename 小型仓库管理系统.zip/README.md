# FE-Collection
> 存放前端学习项目文件仓库

1. `react`文件夹存放react源码,版本为17.0.2
2. `my-debug-react`文件夹搭建了本地调账react源码环境, 使用react版本为17.0.2
3. Javascript_30是一个用原生js写的练习功能库，来记录学习过程，git来源： https://github.com/wesbos/JavaScript30 ，

