import React from 'react';

const Example = (props) => {
  return (
    <div>
      Example
    </div>
  );
};

Example.propTypes = {
};

export default Example;
