/**
 * Created by wyf on 2017/1/18.
 */

const PAGE_SIZE = 10;

module.exports = {
    PAGE_SIZE: PAGE_SIZE
};