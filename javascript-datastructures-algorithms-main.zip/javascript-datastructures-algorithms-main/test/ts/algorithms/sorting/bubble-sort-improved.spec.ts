import { modifiedBubbleSort } from '../../../../src/ts/index';
import { testSortAlgorithm } from './sort-algorithm-tests';

testSortAlgorithm(modifiedBubbleSort, 'Bubble Sort - Improved');

