const { lcsRecursive } = PacktDataStructuresAlgorithms;

const wordX = 'acbaed';
const wordY = 'abcadf';

console.log('lcsRecursive', lcsRecursive(wordX, wordY));
